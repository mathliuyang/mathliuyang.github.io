AIDING Paper Workflow Package

Contents:
- AIDING_Paper_Workflow_SOP.docx / .tex
- AIDING_Cover_Letter_Template.docx / .tex
- AIDING_Response_to_Reviewers_Template.docx / .tex
- AIDING_Submission_Checklist.docx / .tex

DOCX files are directly editable in Microsoft Word.
TEX files are UTF-8 and should be compiled with XeLaTeX.
Target journal instructions always override this general package.
